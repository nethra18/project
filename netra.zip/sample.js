"use strict";

var x = 10;

if (x == 10) {
  var _x = 20;
  console.log(_x); // 20;
}

console.log(x); // 10
