"use strict";

var a = 10;
a = 20;
a = a + 5;
console.log(a);
