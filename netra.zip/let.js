let x = 10;
if (x == 10) {
    let x = 20;
    console.log(x); // 20;
}
console.log(x); // 10