var x="hai";
console.log(x);